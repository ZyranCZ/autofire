-- A/B Button Autofire for Gen1Recomp
--
-- Holding A and/or B re-presses it on a timer.  Three knobs, all in Options:
--
--   BUTTONS -- which buttons autofire applies to (A, B, both, or OFF).
--   DELAY   -- how long a button has to stay down before autofire starts.
--              A tap shorter than this is exactly one press, which is the
--              whole point: without it, one press reads as a burst.
--   RATE    -- how often it repeats once autofire is running.
--
-- Delay and rate are shared: both buttons run on the same timings.  Their
-- countdowns are tracked separately though, so holding A and then pressing B
-- gives B its own delay window instead of inheriting A's head start.
--
-- The timings are offered in milliseconds but stored as a whole number of
-- logic steps.  The game advances on a fixed 60Hz clock
-- (src/core/FixedStep.lua), so one step is 16.67ms and that is the finest an
-- input can be repeated -- the offered values are the ones that land on an
-- exact step count, rather than a free-typed number the engine would
-- silently round anyway.
--
-- The work happens in the "input.step" hook, which Game:step calls once per
-- logic step immediately BEFORE Input:step promotes queued presses to this
-- step's edges.  That is the seam the engine documents for exactly this
-- ("autoplay, accessibility drivers, input visualizers"), and it means an
-- injected press is visible to the same tick a physical one would be.
--
-- Injection is a push onto input.pressQueue.  Input:step turns every queued
-- name into a `pressed` edge; because a real key is still holding the
-- button, its source table is non-empty and the held state carries on
-- untouched.  We never write input.state ourselves, so the
-- A+B+SELECT+START soft reset (Input:softResetHeld) still counts only
-- genuinely held buttons -- including when autofire is driving both A and B.

local BUTTONS = { "a", "b" }

-- which physical buttons each BUTTONS choice drives
local BUTTON_SETS = {
  off = {},
  a = { a = true },
  b = { b = true },
  ab = { a = true, b = true },
}

local BUTTON_CHOICES = {
  { "OFF", "off" },
  { "A ONLY", "a" },
  { "B ONLY", "b" },
  { "A AND B", "ab" },
}

-- { label, steps } -- steps * (1/60)s is the real interval
local DELAY_CHOICES = {
  { "150 MS", 9 },
  { "200 MS", 12 },
  { "250 MS", 15 },
  { "300 MS", 18 },
  { "400 MS", 24 },
  { "500 MS", 30 },
}

local RATE_CHOICES = {
  { "33 MS", 2 },
  { "50 MS", 3 },
  { "67 MS", 4 },
  { "83 MS", 5 },
  { "100 MS", 6 },
  { "133 MS", 8 },
  { "167 MS", 10 },
}

local SCOPE_CHOICES = {
  { "EVERYWHERE", "all" },
  { "BATTLE ONLY", "battle" },
  { "WORLD ONLY", "world" },
}

return function(mod)
  mod.options:define({
    { key = "buttons", label = "AUTOFIRE BUTTONS", type = "choice",
      default = "ab", choices = BUTTON_CHOICES },
    { key = "delay", label = "HOLD BEFORE REPEAT", type = "choice",
      default = 15, choices = DELAY_CHOICES },
    { key = "rate", label = "REPEAT EVERY", type = "choice",
      default = 3, choices = RATE_CHOICES },
    -- BATTLE ONLY is the escape hatch for the overworld's hazards: holding A
    -- re-triggers whatever you are facing, a yes/no prompt that appears
    -- mid-hold answers itself, and held B repeats cancel, which walks back
    -- out of menus.  WORLD ONLY is the mirror, for players who want autofire
    -- for overworld text and menus but keep battles fully manual so a held
    -- button cannot pick a move or burn a turn on its own.
    { key = "scope", label = "AUTOFIRE IN", type = "choice",
      default = "all", choices = SCOPE_CHOICES },
  })

  -- cached rather than read per step: options:get walks the schema on a
  -- miss, and this runs 60 times a second for every tracked button
  local active, delaySteps, rateSteps, scope

  local function readOptions()
    active = BUTTON_SETS[mod.options:get("buttons")] or BUTTON_SETS.off
    delaySteps = tonumber(mod.options:get("delay")) or 15
    rateSteps = math.max(1, tonumber(mod.options:get("rate")) or 3)
    scope = mod.options:get("scope") or "all"
  end

  readOptions()
  mod.events:on("mod.options_changed", function(payload)
    if payload and payload.mod == "a_autofire" then readOptions() end
  end)

  -- battle.started / battle.ended bracket every battle, so scope can be
  -- answered without reaching into the state stack
  local inBattle = false
  mod.events:on("battle.started", function() inBattle = true end)
  mod.events:on("battle.ended", function() inBattle = false end)

  -- per button: consecutive steps held, and steps since the last injection.
  -- Separate entries because A and B are held independently.
  local track = {}
  for _, btn in ipairs(BUTTONS) do
    track[btn] = { held = 0, since = 0 }
  end

  local function scopeAllows()
    if scope == "battle" then return inBattle end
    if scope == "world" then return not inBattle end
    return true
  end

  -- true when this button is already queued this step -- a real press
  -- landed, or another tool mod injected one.  Never stack a second edge.
  local function alreadyQueued(input, button)
    for _, queued in ipairs(input.pressQueue or {}) do
      if queued == button then return true end
    end
    return false
  end

  local function stepButton(input, button)
    local t = track[button]

    if not input:isDown(button) then
      -- released (or never held, or cleared by Input:reset on focus loss)
      t.held = 0
      t.since = 0
      return
    end

    -- A real press edge is queued this step.  Usually that is the first
    -- step of a hold and the counters are already zero, but it also covers
    -- a release+press that both landed inside one logic step: the held
    -- state never dipped, so without this the delay would not re-arm and a
    -- fast double tap would resume autofire mid-burst.  A second source
    -- claiming the button mid-hold re-arms for the same reason.
    local fresh = alreadyQueued(input, button)
    if fresh then
      t.held = 0
      t.since = 0
    end

    t.held = t.held + 1

    -- the counters keep running even when this button is not autofiring, so
    -- switching BUTTONS mid-hold cannot release a backlog of repeats
    if not active[button] or not scopeAllows() then
      t.since = 0
      return
    end

    if t.held <= delaySteps then
      -- still inside the initial hold window: one tap stays one press
      t.since = 0
      return
    end

    t.since = t.since + 1
    if t.since >= rateSteps and not fresh then
      t.since = 0
      input.pressQueue[#input.pressQueue + 1] = button
    end
  end

  mod.hooks:wrap("input.step", function(next, game)
    local input = game and game.input
    if not input or not input.isDown then
      return next()
    end

    for _, button in ipairs(BUTTONS) do
      stepButton(input, button)
    end

    return next()
  end)

  -- published so a test (or another mod) can inspect the timing without a
  -- live Game
  mod.exports.stateForTest = function()
    return { track = track, delaySteps = delaySteps,
             rateSteps = rateSteps, active = active }
  end

  local names = {}
  for _, btn in ipairs(BUTTONS) do
    if active[btn] then names[#names + 1] = btn:upper() end
  end
  mod.log:info("autofire ready for [%s]: %d-step delay, repeat every %d steps",
               #names > 0 and table.concat(names, "+") or "NONE",
               delaySteps, rateSteps)
end
